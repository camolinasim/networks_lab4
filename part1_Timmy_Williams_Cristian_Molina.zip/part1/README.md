> To run the program, install mininet with sudo apt install mininet

> Then, run sudo apt-get install openvswitch-testcontroller

> run sudo ln /usr/bin/ovs-testcontroller /usr/bin/controller

> run python part1.py
